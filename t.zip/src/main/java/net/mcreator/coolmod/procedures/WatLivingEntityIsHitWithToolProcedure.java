package net.mcreator.coolmod.procedures;

import java.util.Map;

public class WatLivingEntityIsHitWithToolProcedure {
	public static void executeProcedure(Map<String, Object> dependencies) {
	}
}
